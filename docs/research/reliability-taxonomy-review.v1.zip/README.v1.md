# Reliability behavior taxonomy review

The complete report is `reliability-behavior-taxonomy-review.v1.md`. Five standalone deliverables are provided as files 01 through 05. Each has its own source register.

`research-handoff.v0.md` preserves the supplied brief unchanged. All research outputs are version 1. Research was performed against publicly accessible sources through September 17, 2026. This is a targeted review, not a claim of exhaustive literature coverage.
